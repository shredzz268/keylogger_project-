from cryptography.fernet import Fernet

# Your encryption key:
key = b'TzusKcGGWM9w4NAdhhqsFUy5YYKHg6rm4PPxE9fY4EA='
cipher = Fernet(key)

def encrypt_data(data: str) -> bytes:
    return cipher.encrypt(data.encode())

def decrypt_data(token: bytes) -> str:
    return cipher.decrypt(token).decode()
