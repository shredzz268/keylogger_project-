from cryptography.fernet import Fernet
import os

# Your Fernet key (the one you generated earlier)
key = b'TzusKcGGWM9w4NAdhhqsFUy5YYKHg6rm4PPxE9fY4EA='
cipher = Fernet(key)

LOG_DIR = "logs/encrypted_logs"

for filename in sorted(os.listdir(LOG_DIR)):
    if filename.endswith(".log"):
        with open(os.path.join(LOG_DIR, filename), 'rb') as f:
            encrypted = f.read()
        try:
            decrypted = cipher.decrypt(encrypted).decode()
            print(f"{filename} => {decrypted}")
        except Exception as e:
            print(f"[!] Failed to decrypt {filename}: {e}")

