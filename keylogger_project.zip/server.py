from flask import Flask, request
import os

app = Flask(__name__)
SAVE_DIR = "logs/received"
os.makedirs(SAVE_DIR, exist_ok=True)

@app.route("/exfil", methods=["POST"])
def receive_file():
    f = request.files['file']
    f.save(os.path.join(SAVE_DIR, f.filename))
    return "Received", 200

if __name__ == "__main__":
    app.run(port=5000)
